class Country:

    index = {'name':0,'population':1,'capital':2,'citypop':3,'continent':4,
             'ind_date':5,'currency':6,'religion':7,'language':8}
    
    # Insert your code here
    # 1a) Implement a constructor    
    
            
    # 1b) Implement a print method        
    
        
    # 1c) Overloaded stringification
    
        
    # Getter methods
    # 1d) Implement a getter method for country name
    
        
    # 1e) Overloaded + and -
    
        
    # If time allows:
    # 1f)  Overloaded == (for index search)
   
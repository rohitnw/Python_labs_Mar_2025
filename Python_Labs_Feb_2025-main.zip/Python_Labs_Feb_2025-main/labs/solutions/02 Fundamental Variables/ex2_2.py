#! /usr/local/bin/python

var = input("Please enter a value: ")

# The value of var as upper case
print(var.upper())

# The number of characters in var
print(len(var))

# Does it contain numeric characters?
print(var.isdecimal())

#! /usr/bin/python
"""
This user written module contains a simple mechanism for
timing operations from Python.  It contains two functions,
start_timer(), which must be called first to initialise the
present time, and end_timer() which calculates the elapsed
CPU time and displays it.

>>> start_timer()
>>> end_timer()    #doctest: +ELLIPSIS
End time    : ... seconds
"""
import os
start_time = None

########################################################
# TIMER FUNCTIONS
def start_timer():
    """
    The start_timer() function marks the start of 
    a timed interval, to be completed by end_timer().
    This function requires no parameters.
    """
    global start_time
    start_time = os.times()[:2]
    return

def end_timer(txt='End time'):
    """
    The end_timer() function completes a timed interval
    started by start_timer.  It prints an optional text
    message (default 'End time') followed by the CPU time
    used in seconds.
    This function has one optional parameter, the text to 
    be displayed.
    """
    end_time = os.times()[:2]
    print ("{0:<12}: {1:01.3f} seconds".format(txt, end_time - start_time))
    return

        
if __name__ == "__main__":
    import doctest
    doctest.testmod()



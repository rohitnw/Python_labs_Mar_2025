#! /usr/bin/env python3
# Author: DCameron
# Version: 1.0
# Description: This is our first script

# name = "Donald Cameron"
name = input("Enter your name: ")

print("My name is", name)
print("My name is " + name)

import random
print("Lucky number is", random.randint(1, 50))

import math
print("Cosine of 0.5 is", math.cos(0.5))
